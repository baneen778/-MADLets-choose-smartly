package com.example.myapplication;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper( Context context) {
        super(context, "Userdata.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Userdetails(name TEXT, contact TEXT,dob TEXT )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists UserDetails");
    }
        public Boolean insertuserdata (String name,String contact,String Dob) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("name", name);
            contentValues.put("contact", contact);
            contentValues.put("Dob", Dob);
            Long result = db.insert("Userdetails", null, contentValues);
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
            public Cursor getdata()
        {
            SQLiteDatabase Db=this.getWritableDatabase();

            Cursor cursor=Db.rawQuery( "Select* from Userdetails" ,null);
            return cursor;


            }
            

    }

